#include <stdio.h>

int fibr (int n);
int fibi (int n);