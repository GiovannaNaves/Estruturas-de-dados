#include <stdio.h>

#ifndef FATH
#define FATH

int fatr (int n);
int fati (int n);

#endif
