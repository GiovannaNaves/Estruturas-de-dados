#ifndef FILA_H
#define FILA_H

#include <string>

class Fila{
    public:
        Fila();
        ~Fila();

        void Enfileirar(std::string item);
        std::string Desenfileirar();

    private:
        

}

#endif