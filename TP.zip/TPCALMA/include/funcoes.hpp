#ifndef FUNCOES_H
#define FUNCOES_H

class Funcoes{
    public:
        std::string TransformaEmPosfixo(std::string infixo);


};

#endif