// implementação geral de um tipo nó

